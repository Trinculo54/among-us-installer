The .exe file is a compiled version of the batch file,

May show as Virus this is just a compiler error.
You may use the batch file also

Thanks,
  Muppley, and Trinculo54

Virus Total:
https://www.virustotal.com/gui/file/3586c31361e2f5100066c9663e5f161bc0936238d65a16c00369896dbacaee77/detection